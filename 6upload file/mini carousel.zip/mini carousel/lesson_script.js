const box = document.querySelectorAll('.box');
const btn = document.querySelector('button');
let count = 0;

btn.onclick = () => {
    count++;

    if(count < box.length){ //4
        box[count - 1].classList.add('hidden');
        box[count].classList.remove('hidden');
    }
    else{
        count = 0;
        box[box.length - 1].classList.add('hidden'); //3
        box[count].classList.remove('hidden');
    }
}










// program to display a text using setTimeout method
// function greet() {
//     alert("I'm first");
// }

// setTimeout(greet, 3000);
// alert("No, I'm first");


// for(let i=0; i<10; i++){
//     setTimeout(function(){
//         alert(i);
//     }, 100)
// }

// var orig = '   foo  ';
// alert(orig.trim()); // 'foo'

// var str = "string not starting with capital";  
 
// function cursive_letter(str) {

//   return str.charAt(0).toUpperCase() + str.slice(1);

// }

// alert(cursive_letter(str)); // "String not starting with capital"


// var str = 'Каждый охотник желает знать';
// function stringToarray(str) {

//     return str.trim().split(" ");

// }

// var arr = stringToarray(str);

// alert(arr); // ['Каждый', 'охотник', 'желает', 'знать']